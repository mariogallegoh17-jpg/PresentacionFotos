PRESENTACIÓN DE FOTOS — Android v1.1

Novedad: antes de iniciar puedes elegir entre 6 transiciones estéticas:
1. Fundido suave
2. Cruzado elegante
3. Deslizar lateral
4. Zoom cinematográfico
5. Desvanecer + zoom
6. Barrido suave

También puedes elegir el tiempo por foto, orden aleatorio y repetición.
Las fotos se seleccionan desde el teléfono y no se suben a un servidor.

Para compilar desde GitHub: sube TODO este proyecto, incluyendo .github/workflows/build.yml.
Luego abre Actions > Compilar APK > Run workflow. Al terminar, descarga el artifact PresentacionFotos-debug.
