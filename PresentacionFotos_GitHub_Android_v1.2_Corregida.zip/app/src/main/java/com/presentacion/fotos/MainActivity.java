package com.presentacion.fotos;

import android.app.Activity;
import android.content.*;
import android.os.*;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import android.net.Uri;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout home;
    FrameLayout player;
    ImageView photo;
    TextView info, count, hint;
    Button start, play;
    ArrayList<Uri> photos = new ArrayList<>(), order = new ArrayList<>();
    int pos = 0, transition = 0;
    boolean playing = false, loop = true, random = false;
    Handler h = new Handler(Looper.getMainLooper());
    Runnable advance;
    int[] secs = {2, 3, 5, 8, 10, 15, 30};
    int delay = 3000;
    String[] transitionNames = {
        "Fundido suave",
        "Cruzado elegante",
        "Deslizar lateral",
        "Zoom cinematográfico",
        "Desvanecer + zoom",
        "Barrido suave"
    };

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        home = findViewById(R.id.home);
        player = findViewById(R.id.player);
        photo = findViewById(R.id.photo);
        info = findViewById(R.id.info);
        count = findViewById(R.id.count);
        start = findViewById(R.id.start);
        play = findViewById(R.id.play);
        hint = findViewById(R.id.transitionHint);

        Spinner sp = findViewById(R.id.seconds);
        String[] labels = {
            "2 segundos", "3 segundos", "5 segundos", "8 segundos",
            "10 segundos", "15 segundos", "30 segundos"
        };
        sp.setAdapter(new ArrayAdapter<String>(
            this, android.R.layout.simple_spinner_dropdown_item, labels));
        sp.setSelection(1);
        sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> a, View v, int p, long id) {
                delay = secs[p] * 1000;
            }
            public void onNothingSelected(android.widget.AdapterView<?> a) {}
        });

        Spinner tr = findViewById(R.id.transition);
        tr.setAdapter(new ArrayAdapter<String>(
            this, android.R.layout.simple_spinner_dropdown_item, transitionNames));
        tr.setSelection(0);
        tr.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> a, View v, int p, long id) {
                transition = p;
                hint.setText(transitionDescription(p));
            }
            public void onNothingSelected(android.widget.AdapterView<?> a) {}
        });

        findViewById(R.id.select).setOnClickListener(v -> pick());

        start.setOnClickListener(v -> {
            random = ((CheckBox) findViewById(R.id.random)).isChecked();
            loop = ((CheckBox) findViewById(R.id.loop)).isChecked();
            order = new ArrayList<>(photos);
            if (random) Collections.shuffle(order);
            pos = 0;
            home.setVisibility(View.GONE);
            player.setVisibility(View.VISIBLE);
            show(false);
            startPlay();
        });

        findViewById(R.id.next).setOnClickListener(v -> next());
        findViewById(R.id.prev).setOnClickListener(v -> prev());
        play.setOnClickListener(v -> {
            if (playing) pause();
            else startPlay();
        });
        findViewById(R.id.back).setOnClickListener(v -> {
            pause();
            player.setVisibility(View.GONE);
            home.setVisibility(View.VISIBLE);
        });
        findViewById(R.id.full).setOnClickListener(v ->
            getWindow().getDecorView().setSystemUiVisibility(5894));
    }

    String transitionDescription(int p) {
        switch (p) {
            case 1:
                return "Dos fotos se mezclan de forma cinematográfica y limpia.";
            case 2:
                return "La siguiente foto entra suavemente desde un lado.";
            case 3:
                return "La nueva foto aparece con un ligero acercamiento cinematográfico.";
            case 4:
                return "Fundido combinado con zoom sutil para un cambio más emotivo.";
            case 5:
                return "Movimiento lateral muy suave, tipo presentación fotográfica.";
            default:
                return "Cambio delicado y limpio, ideal para fotos personales.";
        }
    }

    void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, 7);
    }

    @Override
    protected void onActivityResult(int r, int c, Intent d) {
        super.onActivityResult(r, c, d);
        if (r != 7 || c != RESULT_OK || d == null) return;

        photos.clear();
        ClipData cd = d.getClipData();
        if (cd != null) {
            for (int i = 0; i < cd.getItemCount(); i++) {
                photos.add(cd.getItemAt(i).getUri());
            }
        } else if (d.getData() != null) {
            photos.add(d.getData());
        }

        info.setText(photos.size() +
            " fotos seleccionadas. Puedes cambiar la transición y el tiempo antes de iniciar.");
        start.setEnabled(!photos.isEmpty());
    }

    void show(boolean animate) {
        if (order.isEmpty()) return;
        Uri u = order.get(pos);
        photo.setImageURI(u);
        count.setText((pos + 1) + " / " + order.size());
        if (animate) animatePhoto();
    }

    void animatePhoto() {
        photo.clearAnimation();
        Animation in;

        switch (transition) {
            case 1:
                in = new AlphaAnimation(0f, 1f);
                in.setDuration(750);
                break;

            case 2:
                in = new TranslateAnimation(
                    Animation.RELATIVE_TO_PARENT, 1f,
                    Animation.RELATIVE_TO_PARENT, 0f,
                    Animation.RELATIVE_TO_PARENT, 0f,
                    Animation.RELATIVE_TO_PARENT, 0f);
                in.setDuration(650);
                in.setInterpolator(new DecelerateInterpolator());
                break;

            case 3:
                in = new ScaleAnimation(
                    1.10f, 1f, 1.10f, 1f,
                    Animation.RELATIVE_TO_SELF, .5f,
                    Animation.RELATIVE_TO_SELF, .5f);
                in.setDuration(900);
                in.setInterpolator(new DecelerateInterpolator());
                break;

            case 4:
                AnimationSet combo = new AnimationSet(true);
                combo.addAnimation(new AlphaAnimation(0f, 1f));
                combo.addAnimation(new ScaleAnimation(
                    1.08f, 1f, 1.08f, 1f,
                    Animation.RELATIVE_TO_SELF, .5f,
                    Animation.RELATIVE_TO_SELF, .5f));
                combo.setDuration(900);
                combo.setInterpolator(new DecelerateInterpolator());
                in = combo;
                break;

            case 5:
                in = new TranslateAnimation(
                    Animation.RELATIVE_TO_PARENT, .35f,
                    Animation.RELATIVE_TO_PARENT, 0f,
                    Animation.RELATIVE_TO_PARENT, 0f,
                    Animation.RELATIVE_TO_PARENT, 0f);
                in.setDuration(800);
                in.setInterpolator(new DecelerateInterpolator());
                break;

            default:
                in = new AlphaAnimation(0f, 1f);
                in.setDuration(900);
                in.setInterpolator(new DecelerateInterpolator());
                break;
        }

        photo.startAnimation(in);
    }

    void startPlay() {
        h.removeCallbacksAndMessages(null);
        playing = true;
        play.setText("Ⅱ");
        advance = () -> next();
        h.postDelayed(advance, delay);
    }

    void pause() {
        h.removeCallbacksAndMessages(null);
        playing = false;
        play.setText("▶");
    }

    void next() {
        if (order.isEmpty()) return;

        if (pos < order.size() - 1) {
            pos++;
        } else {
            if (!loop) {
                pause();
                return;
            }
            pos = 0;
            if (random) Collections.shuffle(order);
        }

        show(true);
        if (playing) startPlay();
    }

    void prev() {
        if (order.isEmpty()) return;
        pos = pos > 0 ? pos - 1 : (loop ? order.size() - 1 : 0);
        show(true);
        if (playing) startPlay();
    }
}
